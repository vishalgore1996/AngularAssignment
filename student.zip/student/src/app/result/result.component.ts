import { prepareSyntheticListenerFunctionName } from '@angular/compiler/src/render3/util';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgClass } from '@angular/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {
  contactform:FormGroup;
  formData:any ={};
  Formmaths:any={};

  overallresult:any='';
 result:any=0;
 n1:any=0;
 n2:any=0;
 n3:any=0;
 n4:any=0;
 mathsgrade:any="";
 mathsgradeshow:any="";
 physicsgrade:any="";
 physicsgradeshow:any="";
 chemistrygrade:any="";
 chemistrygradeshow:any="";
 englishgrade:any="";
 englishgradeshow:any="";
 totalmarks:any="";
 totalmarksshow:any="";
 percentage:any="";
 percentageshow:any="";

  
  constructor() { 
    this.contactform=new FormGroup({
      maths:new  FormControl("",[Validators.required,Validators.minLength(2)]),
      physics:new FormControl("",[Validators.required,Validators.minLength(2)]),
      chemistry:new FormControl("",[Validators.required,Validators.minLength(2)]),
      english:new FormControl("",[Validators.required,Validators.minLength(2)]),
      
    });
  }
  
  add(){
    if(this.n1 <40){
      console.log("fail")
      this.overallresult=false
      this.mathsgrade="fail"
      }
    else if(this.n1<50){
      console.log("C grade")
      this.mathsgrade="C grade"
      } else if(this.n1<60){
      console.log("C+ grade")
      this.mathsgrade="C+ grade"
      } else if(this.n1 <70){
        console.log("B grade")
        this.mathsgrade="B grade"
      } else if(this.n1 <80){
        console.log("B+ grade")
        this.mathsgrade="B+ grade"
      }else{
        console.log("A grade")
        this.mathsgrade="A grade"
      }

     this.mathsgradeshow="maths : "+this.mathsgrade

  }

  add2
  (){
    if(this.n2<40){
      console.log("fail")
      this.overallresult=false
      this.physicsgrade="fail"
      }
    else if(this.n2 <50){
      console.log("C grade")
      this.physicsgrade="C grade"
      } else if(this.n2<60){
      console.log("C+ grade")
      this.physicsgrade="C+ grade"
      } else if(this.n2 <70){
        console.log("B grade")
        this.physicsgrade="B grade"
      } else if(this.n2 <80){
        console.log("B+ grade")
        this.physicsgrade="B+ grade"
      }else{
        console.log("A grade")
        this.physicsgrade="A grade"
      }

      this.physicsgradeshow="physics :"+this.physicsgrade

  }

  
  add3(){
    if(this.n3 <40){
      console.log("fail")
      this.overallresult=false
      this.chemistrygrade="fail"
      }
    else if(this.n3 <50){
      console.log("C grade")
      this.chemistrygrade="C grade"
      } else if(this.n3 <60){
      console.log("C+ grade")
      this.chemistrygrade="C+ grade"
      } else if(this.n3 <70){
        console.log("B grade")
        this.chemistrygrade="B grade"
      } else if(this.n3 <80){
        console.log("B+ grade")
        this.chemistrygrade="B+ grade"
      }else{
        console.log("A grade")
        this.chemistrygrade="A grade"
      }

      this.chemistrygradeshow="chemistry : "+this.chemistrygrade
  }

  add4(){
    if(this.n4 <40){
      console.log("fail")
      this.overallresult=false;
      this.englishgrade="fail"
      }
    else if(this.n4 <50){
      console.log("C grade")
      this.englishgrade="C grade"
      } else if(this.n4 <60){
      console.log("C+ grade")
      this.englishgrade="C+ grade"
      } else if(this.n4 <70){
        console.log("B grade")
        this.englishgrade="B grade"
      } else if(this.n4 <80){
        console.log("B+ grade")
        this.englishgrade="B+ grade"
      }else{
        console.log("A grade")
        this.englishgrade="A grade"
      }

      this.englishgradeshow="english : "+this.englishgrade

  }



  ngOnInit(): void {

  }
    submit(){
      console.log(this.formData);
     this.result=this.formData
     this.n1=this.result.maths
     this.n2=this.result.physics
     this.n3=this.result.chemistry
     this.n4=this.result.english

     this.totalmarks =Number(this.n1)+Number(this.n2)+Number(this.n3)+Number(this.n4);

     this.totalmarksshow="total marks : "+this.totalmarks
     console.log("totalmarks"+this.totalmarks);

     this.percentage=this.totalmarks/4;
     
     this.percentageshow="percentage : "+this.percentage
//     console.log(this.overallresult);
    
     

     console.log("percentage"+this.percentage)

    this.add()
    this.add2()
    this.add3()
    this.add4()
  
    
    if(this.overallresult==true)

    this.overallresult= "Overall Result= passed"
else
   this.overallresult="Overall fail"


     
     
    }
   
  

}



