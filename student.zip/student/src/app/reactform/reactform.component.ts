import { prepareSyntheticListenerFunctionName } from '@angular/compiler/src/render3/util';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
//import { NgClass } from '@angular/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-reactform',
  templateUrl: './reactform.component.html',
  styleUrls: ['./reactform.component.css']
})
export class ReactformComponent implements OnInit {
  contactform:FormGroup;
  formData:any={};
  studentdata:any;
  fname:any;
  lname:any;
  Class:any;
  RollNo:any;
  datasubmitted:any="Registration pending";
  constructor() { 
    this.contactform=new FormGroup({
      fname:new FormControl("",[Validators.required,Validators.minLength(2)]),
      lname:new FormControl("",[Validators.required,Validators.minLength(2)]),
      Class:new FormControl("",[Validators.required,Validators.minLength(2)]),
      RollNo:new FormControl("",[Validators.required,Validators.minLength(2)])
    });

  }

  ngOnInit(): void {
  }
 onSubmit(){
  console.log(this.formData);
  
  this.datasubmitted="Congrats Your Registration Completed"
}
}