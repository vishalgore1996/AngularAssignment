import { prepareSyntheticListenerFunctionName } from '@angular/compiler/src/render3/util';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgClass } from '@angular/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-item-info',
  templateUrl: './item-info.component.html',
  styleUrls: ['./item-info.component.css']
})
export class ItemInfoComponent implements OnInit {
  contactform:FormGroup;
  formData:any ={};
  Formmaths:any={};
  totalPriceShow:any;
  totalPriceShows:any;
 totalPrice1:any;
 totalPrice1s:any;
 result1:any=0;
 i1:any=0;
 p1:any=0;
 q1:any=0;
 d1:any=0;

 totalPrice5:any;
 totalPrice5s:any;
 result5:any=0;
 i5:any=0;
 p5:any=0;
 q5:any=0;
 d5:any=0;


 totalPrice2:any;
 totalPrice2s:any;
 result2:any=0;
 i2:any=0;
 p2:any=0;
 q2:any=0;
 d2:any=0;


 totalPrice3:any;
 totalPrice3s:any;
 result3:any=0;
 i3:any=0;
 p3:any=0;
 q3:any=0;
 d3:any=0;


 totalPrice4:any;
 totalPrice4s:any;
 result4:any=0;
 i4:any=0;
 p4:any=0;
 q4:any=0;
 d4:any=0;
  
  constructor() { 
    this.contactform=new FormGroup({
      iname1:new  FormControl("",[Validators.required,Validators.minLength(2)]),
      iname2:new  FormControl("",[Validators.required,Validators.minLength(2)]),
      iname3:new  FormControl("",[Validators.required,Validators.minLength(2)]),
      iname4:new  FormControl("",[Validators.required,Validators.minLength(2)]),
      iname5:new  FormControl("",[Validators.required,Validators.minLength(2)]),
      price1:new FormControl("",[Validators.required,Validators.minLength(2)]),
      price2:new FormControl("",[Validators.required,Validators.minLength(2)]),
      price3:new FormControl("",[Validators.required,Validators.minLength(2)]),
      price4:new FormControl("",[Validators.required,Validators.minLength(2)]),
      price5:new FormControl("",[Validators.required,Validators.minLength(2)]),
      qty1:new FormControl("",[Validators.required,Validators.minLength(2)]),
      qty2:new FormControl("",[Validators.required,Validators.minLength(2)]),
      qty3:new FormControl("",[Validators.required,Validators.minLength(2)]),
      qty4:new FormControl("",[Validators.required,Validators.minLength(2)]),
      qty5:new FormControl("",[Validators.required,Validators.minLength(2)]),
      dis1:new FormControl("",[Validators.required,Validators.minLength(2)]),
      disc2:new FormControl("",[Validators.required,Validators.minLength(2)]),
      disc3:new FormControl("",[Validators.required,Validators.minLength(2)]),
      disc4:new FormControl("",[Validators.required,Validators.minLength(2)]),
      disc5:new FormControl("",[Validators.required,Validators.minLength(2)]),
      
    });
  }
  
  
  ngOnInit(): void {

  }
    submit(){

      console.log(this.formData);
     this.result1=this.formData
     this.i1=this.result1.iname1
     this.p1=this.result1.price1
     this.q1=this.result1.qty1
     this.d1=this.result1.disc1
     this.totalPrice1 =+Number(this.p1)*Number(this.q1)*(100-Number(this.d1))/100;
     this.totalPrice1s="Total PRICE1 :"+Number(this.totalPrice1);
     //console.log("totalprice1"+this.totalPrice1);

    this.result2=this.formData
    this.i2=this.result2.iname2
     this.p2=this.result2.price2
     this.q2=this.result2.qty2
     this.d2=this.result2.disc2
     this.totalPrice2 =Number(this.p2)*Number(this.q2)*(100-Number(this.d2))/100;
     this.totalPrice2s="Total PRICE2:"+Number(this.totalPrice2);
    //// console.log("totalprice2"+this.totalPrice2);

     this.result3=this.formData
    this.i3=this.result3.iname3
     this.p3=this.result3.price3
     this.q3=this.result3.qty3
     this.d3=this.result3.disc3
     this.totalPrice3 =Number(this.p3)*Number(this.q3)*(100-Number(this.d3))/100;
     this.totalPrice3s="Total PRICE3 :"+Number(this.totalPrice3);
     //console.log("totalprice3"+this.totalPrice3);

     this.result4=this.formData
    this.i4=this.result4.iname4
     this.p4=this.result4.price4
     this.q4=this.result4.qty4
     this.d4=this.result4.disc4
     this.totalPrice4 =Number(this.p4)*Number(this.q4)*(100-Number(this.d4))/100;
     this.totalPrice4s="Total PRICE4 :"+Number(this.totalPrice4);
    // console.log("totalprice4"+this.totalPrice4);

     this.result5=this.formData
    this.i5=this.result5.iname5
     this.p5=this.result5.price5
     this.q5=this.result5.qty5
     this.d5=this.result5.disc5
     this.totalPrice5 =Number(this.p5)*Number(this.q5)*(100-Number(this.d5))/100;
     this.totalPrice5s="Total PRICE5 :"+Number(this.totalPrice5);
     //console.log("totalprice4"+this.totalPrice5);

     

      console.log(this.formData);
     this.totalPriceShow=Number(this.totalPrice1)+Number(this.totalPrice2)+Number(this.totalPrice3)+Number(this.totalPrice4)+Number(this.totalPrice5);
     //console.log("totalprice"+Number(this.totalPriceShow));
     this.totalPriceShows="Total PRICE Of all Items    :"+Number(this.totalPriceShow);
    
    
    }
  
  

}



